"tau" <-
0.1
"alpha.star" <-
0
"beta" <-
0
"gamma" <-
0
