"tau" <-
1
"alpha0" <-
0
"alpha1" <-
0
"alpha2" <-
0
"alpha12" <-
0
