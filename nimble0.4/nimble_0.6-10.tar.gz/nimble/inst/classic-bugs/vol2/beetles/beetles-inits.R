"alpha.star" <- 0
"beta" <- 0
