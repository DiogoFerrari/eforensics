"theta" <-
structure(c(5, 5, 5, 5, 5, 2, 2, 2, 2, 2, -6, -6, -6, -6, -6), .Dim = as.integer(c(5, 
3)))
"mu" <-
c(5, 2, -6)
"tau" <-
structure(c(0.1, 0, 0, 0, 0.1, 0, 0, 0, 0.1), .Dim = as.integer(c(3, 
3)))
"tauC" <-
20
