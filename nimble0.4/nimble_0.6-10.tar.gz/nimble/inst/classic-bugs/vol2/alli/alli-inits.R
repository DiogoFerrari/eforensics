"alpha" <-
c(NA, 0, 0, 0, 0)
"beta" <-
structure(c(NA, NA, NA, NA, NA, 0, 0, 0, NA, 0, 0, 0, NA, 0, 
0, 0, NA, 0, 0, 0), .Dim = as.integer(c(4, 5)))
"gamma" <-
structure(c(NA, NA, NA, 0, NA, 0, NA, 0, NA, 0), .Dim = as.integer(c(2, 
5)))
