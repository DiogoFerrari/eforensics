"Ann1" <-
0
"Brian1" <-
0
"Clare" <-
1
"Diane" <-
1
"Eric1" <-
1
"Fred" <-
1
"Gene" <-
2
"Henry1" <-
1
"Ian" <-
1
"Jane" <-
3
